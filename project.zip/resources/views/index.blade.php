@include('include.header')

<section id="container-2">
    <div class="container-2-list">
      <a href="{{url('login/1')}}">Staff Login Portal</a>
    </div>
    <div class="container-2-list">
      <a href="{{url('login/2')}}">Student Login Portal</a>
    </div>
</section>

@include('include.footer')
    