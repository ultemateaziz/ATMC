<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="staff">
   <h2>MENU</h2>
   <div class="menu-main">
        <div class="menu">
            <ul>
                <li><a href="<?php echo e(url('/upload_index')); ?>">UPLOAD PROJECT LIST</a></li>
                <li><a href="<?php echo e(url('/view-group')); ?>">VIEW GROUPS</a></li>
                <li><a href="#">VIEW SFIA SKILLS</a></li>
                <li><a href="#">NOTIFY STUDENT</a></li>
                <li><a href="#">Manual Groups</a></li>
                <li><a href="<?php echo e(url('/student_register')); ?>">Create a Student</a></li>
                <li style="background: #8282f6"><a href="<?php echo e(url('/logout')); ?>" >Logout</a></li>
            </ul>
        </div>
    </div>
</section>



<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ATMC Website Project\project\resources\views/staff/staff.blade.php ENDPATH**/ ?>