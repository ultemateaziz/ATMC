<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATMC - Home </title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <section id="container">
        <img src="./images/ATMC_.jpg" alt="">
    </section>
    <section id="container-2">
       <div class="container-2-list">
         <a href="code/staff-login.html">Staff Login Portal</a>
       </div>
       <div class="container-2-list">
         <a href="code/student-login.html">Student Login Portal</a>
       </div>
    </section>
    <script src="js/script.js"></script>
</body>
</html><?php /**PATH G:\ATMC\project\resources\views/index.blade.php ENDPATH**/ ?>