<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="container-2">
    <div class="container-2-list">
      <a href="<?php echo e(url('login/1')); ?>">Staff Login Portal</a>
    </div>
    <div class="container-2-list">
      <a href="<?php echo e(url('login/2')); ?>">Student Login Portal</a>
    </div>
</section>

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php /**PATH C:\xampp\htdocs\ATMC Website Project\project\resources\views/index.blade.php ENDPATH**/ ?>