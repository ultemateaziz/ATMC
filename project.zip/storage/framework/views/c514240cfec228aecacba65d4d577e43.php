<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="staff">
    <div class="upload">
      <h3>VIEW GROUPS</h3>
    </div>
</section>
   <br>
<section id="project">
    <div class="project">
        <?php $__currentLoopData = $final; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="project-list">
            <h3>Group - <?php echo e($key); ?></h3>
            <ul>
                <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($val); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--
        <div class="project-list">
        <h3>Group - Project 1</h3>
        </div>
        <div class="project-list">
        <h3>Group - Project 2</h3>
        </div>
        <div class="project-list">
        <h3>Group - Project 3</h3>
        </div>
        <div class="project-list">
        <h3>Group - Project 4</h3>
        </div>
        <div class="project-list">
         <h3>Group - Project 5</h3>
        </div>
        <div class="project-list">
         <h3>Group - Project 6</h3>
        </div>
        <div class="project-list">
           <h3>Group - Project 7</h3>
        </div>
        <div class="project-list">
         <h3>Group - Project 8</h3>
        </div>
        <div class="project-list">
         <h3>Group - Project 9</h3>
        </div>
        -->
    </div>

</section>


<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\ATMC Website Project\project\resources\views/staff/team.blade.php ENDPATH**/ ?>