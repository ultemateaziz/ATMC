<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATMC - <?php if(isset($title)): ?><?php echo e($title); ?><?php else: ?> Home <?php endif; ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    
    <script src="<?php echo e(asset('js/jquery-3.7.0.min.js')); ?>"></script>
</head>
<body>
    <section id="container">
        <img src="<?php echo e(asset('images/ATMC_.jpg')); ?>" alt="">
    </section><?php /**PATH C:\xampp\htdocs\ATMC Website Project\project\resources\views/include/header.blade.php ENDPATH**/ ?>