<?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section id="staff-login">
    <h2><?php echo e($user); ?> LOGIN PORTAL</h2>
    <br>
    <div class="login-main">
        <div class="login">
            <form id="myForm" action="<?php echo e(url('/login-action')); ?>" method="POST">
                <div>
                    <input type="text" name="email" placeholder="email" id="email" required>
                </div>
               
                <div>
                    <input type="password" name="password" placeholder="password" id="pass" required>
                </div>
                <?php echo csrf_field(); ?>
                <button type="submit" id="sub_btn">LOGIN</button>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span style="color: red;"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
        </div>
    </div>
    <?php $__errorArgs = ['restricted'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="popup" id="popup" style="display: block;">
        <div class="popup-content">
            <span class="close" id="closePopupBtn">&times;</span>
            <h3>Error</h3>
            <br>
            <p id="popupMessage" style="text-align: center;"><?php echo e($message); ?></p>
            
        </div>
    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</section>

<?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    $('#sub_btn').click(function (){
        email = $('#email').val();
        password = $('#pass').val();

        $('#email').next('span').remove();
        $('#pass').next('span').remove();
        var regex = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(email == '' || password == ''){
            if(email == ''){
                $('#email').parent().append("<span style='color: red;'>Please fill the Email</span>");
            }

            if(password == ''){
                $('#pass').parent().append("<span style='color: red;'>Please fill the Password</span>");
            }

            return false;
        }else if(!regex.test(email)) {
            $('#email').parent().append("<span style='color: red;'>Please enter valid mail address</span>")
            return false;
        }else{
            return true;
        }
    });

    $('#closePopupBtn').click(function (){
        $('#popup').hide();
    })
</script>
<?php /**PATH C:\xampp\htdocs\ATMC Website Project\project\resources\views/auth/login.blade.php ENDPATH**/ ?>