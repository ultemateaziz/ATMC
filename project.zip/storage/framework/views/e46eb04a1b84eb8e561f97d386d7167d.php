<!--<script src="js/script.js"></script> -->
</body>
</html><?php /**PATH C:\xampp\htdocs\ATMC Website Project\project\resources\views/include/footer.blade.php ENDPATH**/ ?>